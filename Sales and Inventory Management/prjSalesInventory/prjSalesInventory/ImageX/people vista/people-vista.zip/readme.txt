People Icons for Vista

Product page:
http://www.777icons.com/libs/people-vista-icons.htm
